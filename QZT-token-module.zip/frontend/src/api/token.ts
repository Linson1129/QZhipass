import axios from 'axios'

/**
 * Token 统计相关 API
 * 对齐 QZhipass 后端约定
 */
const http = axios.create({
  baseURL: '/api',
  timeout: 15000
})

http.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token') || localStorage.getItem('token')
  const userId = localStorage.getItem('currentUserId') || localStorage.getItem('userId')
  if (token) config.headers.Authorization = `Bearer ${token}`
  if (userId) config.headers['X-User-Id'] = String(userId)
  return config
})

export interface TokenUsage {
  daily_limit: number
  used_today: number
  remaining: number
  status: 'ok' | 'over' | 'normal' | 'warning'
  department?: string
  name?: string
}

export interface ChatCheckResult {
  allowed: boolean
  message?: string
  used?: number
  quota?: number
}

export async function getUserTokenUsage(): Promise<TokenUsage> {
  const { data } = await http.get('/v1/user/token/usage')
  const raw = data.rawData || data.data || data
  return {
    daily_limit: raw.daily_limit ?? raw.quota ?? 100000,
    used_today: raw.used_today ?? raw.used ?? 0,
    remaining: raw.remaining ?? Math.max(0, (raw.daily_limit ?? 100000) - (raw.used_today ?? 0)),
    status: raw.status === 'over' ? 'over' : (raw.status || 'ok'),
    department: raw.department,
    name: raw.name
  }
}

export async function checkTokenBeforeChat(payload: {
  userId?: number
  model?: string
  estimatedTokens?: number
}): Promise<ChatCheckResult> {
  const { data } = await http.post('/v1/chat/check', {
    userId: payload.userId,
    model: payload.model || '千问',
    estimatedTokens: payload.estimatedTokens ?? 5000
  })
  if (typeof data.allowed === 'boolean') return data
  return {
    allowed: !!(data.success && !(data.data?.overQuota)),
    message: data.message,
    used: data.used ?? data.data?.used,
    quota: data.quota ?? data.data?.quota
  }
}

export async function recordChatUsage(payload: {
  userId?: number
  model?: string
  promptTokens: number
  completionTokens: number
}) {
  const { data } = await http.post('/v1/chat/usage', payload)
  return data
}

export async function getAdminTokenDashboard() {
  const { data } = await http.get('/v1/admin/token/dashboard', {
    headers: { 'X-Admin-Key': localStorage.getItem('adminKey') || 'admin-secret-key' }
  })
  return data.rawData || data.data || data
}

export async function getAdminTokenUsage() {
  const { data } = await http.get('/v1/admin/token/usage', {
    headers: { 'X-Admin-Key': localStorage.getItem('adminKey') || 'admin-secret-key' }
  })
  return data.data || data.rawData || data
}

export async function updateGlobalQuota(daily_token_limit: number) {
  const { data } = await http.put(
    '/v1/admin/token/quota',
    { daily_token_limit },
    { headers: { 'X-Admin-Key': localStorage.getItem('adminKey') || 'admin-secret-key' } }
  )
  return data
}
