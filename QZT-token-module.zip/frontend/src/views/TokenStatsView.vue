<template>
  <div class="token-stats-page min-h-screen bg-slate-50">
    <!-- 顶部导航 -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-40">
      <div class="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white">
            <el-icon :size="20"><Monitor /></el-icon>
          </div>
          <span class="text-xl font-bold tracking-tight text-slate-900">企智通</span>
          <el-tag size="small" type="info" effect="plain" class="ml-1">个人 Token</el-tag>
        </div>

        <div class="flex items-center gap-4">
          <!-- 迷你用量 -->
          <div class="hidden sm:flex items-center gap-3 px-4 py-1.5 bg-slate-50 rounded-2xl border border-slate-200">
            <div class="text-right leading-tight">
              <div class="text-sm font-mono font-semibold text-slate-800">
                {{ formatNum(usage.used_today) }}
                <span class="text-slate-400 font-normal">/</span>
                {{ formatNum(usage.daily_limit) }}
              </div>
              <div class="text-[10px] text-slate-500">今日 Token</div>
            </div>
            <el-progress
              :percentage="percent"
              :stroke-width="8"
              :show-text="false"
              :color="progressColor"
              class="w-16"
            />
          </div>

          <div class="flex items-center gap-2">
            <el-avatar :size="32" class="bg-blue-100 text-blue-700 font-semibold">
              {{ (userName || '用').charAt(0) }}
            </el-avatar>
            <div class="hidden md:block leading-tight">
              <div class="text-sm font-medium text-slate-800">{{ userName || '用户' }}</div>
              <div class="text-xs text-slate-500">{{ usage.department || '—' }}</div>
            </div>
          </div>

          <el-button text circle @click="refresh" :loading="loading">
            <el-icon><Refresh /></el-icon>
          </el-button>
        </div>
      </div>
    </header>

    <main class="max-w-6xl mx-auto px-6 py-8 space-y-6">
      <!-- 标题 -->
      <div>
        <h1 class="text-2xl font-bold text-slate-900 tracking-tight">我的 Token 统计</h1>
        <p class="text-slate-500 mt-1 text-sm">今日用量实时展示 · 配额健康状态 · 使用趋势</p>
      </div>

      <!-- 主用量卡片 -->
      <el-card shadow="never" class="rounded-2xl border-slate-100">
        <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <div class="text-xs font-semibold tracking-widest text-blue-600 uppercase mb-1">今日个人用量</div>
            <div class="flex items-baseline gap-2">
              <span class="text-5xl md:text-6xl font-semibold tabular-nums tracking-tighter text-slate-900">
                {{ formatNum(usage.used_today) }}
              </span>
              <span class="text-xl text-slate-400">tokens</span>
            </div>
            <div class="text-slate-400 mt-1 text-sm">
              限额 <span class="font-mono font-medium text-slate-600">{{ formatNum(usage.daily_limit) }}</span>
            </div>
          </div>

          <div class="text-left md:text-right">
            <el-tag
              :type="statusTagType"
              size="large"
              effect="light"
              round
              class="!text-sm !px-4 !py-1"
            >
              <el-icon class="mr-1"><component :is="statusIcon" /></el-icon>
              {{ statusText }}
            </el-tag>
            <div class="mt-3 text-sm text-slate-600">
              剩余可用
              <span class="font-mono font-semibold text-emerald-600 text-lg ml-1">
                {{ formatNum(usage.remaining) }}
              </span>
            </div>
          </div>
        </div>

        <!-- 进度条 -->
        <div class="mt-8">
          <el-progress
            :percentage="percent"
            :stroke-width="12"
            :color="progressColor"
            :format="() => percent + '%'"
          />
          <div class="flex justify-between text-xs text-slate-500 mt-2">
            <span>0</span>
            <span>已使用 {{ percent }}%</span>
            <span>{{ formatNum(usage.daily_limit) }}</span>
          </div>
        </div>
      </el-card>

      <!-- 下方两栏 -->
      <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <!-- 本周趋势（占位，可接真实接口） -->
        <el-card shadow="never" class="lg:col-span-3 rounded-2xl border-slate-100">
          <template #header>
            <div class="flex items-center gap-2 font-semibold text-slate-800">
              <el-icon class="text-blue-600"><TrendCharts /></el-icon>
              本周 Token 消耗趋势
            </div>
          </template>
          <div class="h-52 flex items-center justify-center text-slate-400 text-sm">
            <div class="text-center">
              <el-icon :size="36" class="mb-2 opacity-40"><DataLine /></el-icon>
              <p>趋势图数据由后端接口提供后展示</p>
              <p class="text-xs mt-1">可对接 /api/v1/user/token/weekly</p>
            </div>
          </div>
        </el-card>

        <!-- 摘要 + 操作 -->
        <el-card shadow="never" class="lg:col-span-2 rounded-2xl border-slate-100 flex flex-col">
          <template #header>
            <span class="font-semibold text-slate-800">使用情况摘要</span>
          </template>

          <div class="space-y-3 flex-1 text-sm">
            <div class="flex justify-between py-2 border-b border-slate-100">
              <span class="text-slate-500">今日已用</span>
              <span class="font-mono font-semibold">{{ formatNum(usage.used_today) }}</span>
            </div>
            <div class="flex justify-between py-2 border-b border-slate-100">
              <span class="text-slate-500">当日限额</span>
              <span class="font-mono font-semibold">{{ formatNum(usage.daily_limit) }}</span>
            </div>
            <div class="flex justify-between py-2 border-b border-slate-100">
              <span class="text-slate-500">剩余可用</span>
              <span class="font-mono font-semibold text-emerald-600">{{ formatNum(usage.remaining) }}</span>
            </div>
            <div class="flex justify-between py-2">
              <span class="text-slate-500">配额健康度</span>
              <span :class="healthClass">{{ healthText }}</span>
            </div>
          </div>

          <el-button
            type="primary"
            size="large"
            class="w-full mt-6 !rounded-xl"
            :disabled="isOver"
            :loading="checking"
            @click="handleStartChat"
          >
            <el-icon class="mr-1"><ChatDotRound /></el-icon>
            发起新对话（检测配额）
          </el-button>
          <p class="text-center text-[11px] text-slate-400 mt-2">
            调用 POST /api/v1/chat/check 检测后进入对话
          </p>
        </el-card>
      </div>

      <!-- 模型与调试区（可选） -->
      <el-card shadow="never" class="rounded-2xl border-slate-100">
        <template #header>
          <span class="font-semibold text-slate-800">调试 / 模拟消耗</span>
        </template>
        <div class="flex flex-wrap items-end gap-4">
          <div>
            <div class="text-xs text-slate-500 mb-1">模型</div>
            <el-input v-model="model" placeholder="千问" style="width: 140px" />
          </div>
          <div>
            <div class="text-xs text-slate-500 mb-1">模拟消耗 Token</div>
            <el-input-number v-model="mockTokens" :min="100" :step="500" />
          </div>
          <el-button type="primary" plain :loading="recording" @click="handleRecord">
            记录一次消耗
          </el-button>
          <el-button @click="refresh" :loading="loading">刷新用量</el-button>
        </div>
        <p v-if="tip" class="mt-3 text-sm" :class="tipOk ? 'text-emerald-600' : 'text-red-500'">
          {{ tip }}
        </p>
      </el-card>
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import {
  Monitor, Refresh, TrendCharts, DataLine, ChatDotRound,
  CircleCheck, Warning, CircleClose
} from '@element-plus/icons-vue'
import {
  getUserTokenUsage,
  checkTokenBeforeChat,
  recordChatUsage,
  type TokenUsage
} from '@/api/token'

const loading = ref(false)
const checking = ref(false)
const recording = ref(false)
const tip = ref('')
const tipOk = ref(true)
const model = ref('千问')
const mockTokens = ref(5000)

const usage = ref<TokenUsage>({
  daily_limit: 100000,
  used_today: 0,
  remaining: 100000,
  status: 'ok'
})

const userName = computed(() =>
  localStorage.getItem('currentUserName') || usage.value.name || '用户'
)

const percent = computed(() => {
  const q = usage.value.daily_limit
  if (!q) return 0
  return Math.min(100, Math.round((usage.value.used_today / q) * 100))
})

const isOver = computed(() =>
  usage.value.status === 'over' || usage.value.used_today >= usage.value.daily_limit
)

const progressColor = computed(() => {
  if (percent.value >= 95) return '#ef4444'
  if (percent.value >= 80) return '#f59e0b'
  return '#3b82f6'
})

const statusTagType = computed(() => {
  if (isOver.value) return 'danger'
  if (percent.value >= 80) return 'warning'
  return 'success'
})

const statusIcon = computed(() => {
  if (isOver.value) return CircleClose
  if (percent.value >= 80) return Warning
  return CircleCheck
})

const statusText = computed(() => {
  if (isOver.value) return '已超额，请联系管理员'
  if (percent.value >= 80) return '用量较高，注意控制'
  return '用量正常'
})

const healthText = computed(() => {
  if (isOver.value) return '超额'
  if (percent.value >= 80) return '偏高'
  return '良好'
})

const healthClass = computed(() => {
  if (isOver.value) return 'font-semibold text-red-500'
  if (percent.value >= 80) return 'font-semibold text-amber-500'
  return 'font-semibold text-emerald-600'
})

function formatNum(n: number) {
  return (n ?? 0).toLocaleString()
}

async function refresh() {
  loading.value = true
  tip.value = ''
  try {
    usage.value = await getUserTokenUsage()
  } catch (e: any) {
    console.error(e)
    ElMessage.error(e?.response?.data?.message || e?.message || '获取用量失败，请确认后端已启动')
  } finally {
    loading.value = false
  }
}

async function handleStartChat() {
  checking.value = true
  tip.value = ''
  try {
    const uid = Number(localStorage.getItem('currentUserId') || localStorage.getItem('userId') || 0)
    const res = await checkTokenBeforeChat({
      userId: uid || undefined,
      model: model.value,
      estimatedTokens: 5000
    })
    if (res.allowed) {
      tipOk.value = true
      tip.value = '✓ 配额检测通过，可以发起对话'
      ElMessage.success('配额检测通过')
      // 真实项目：router.push('/chat') 或打开对话抽屉
    } else {
      tipOk.value = false
      tip.value = `✗ 配额不足。已用 ${formatNum(res.used || 0)} / 限额 ${formatNum(res.quota || 0)}`
      ElMessageBox.alert(
        '按系统规则，今日用量已达到或即将达到限额，无法发起新对话。请联系管理员调整限额或明日再试。',
        '今日 Token 已用尽',
        { type: 'error', confirmButtonText: '我知道了' }
      )
      await refresh()
    }
  } catch (e: any) {
    tipOk.value = false
    tip.value = '检测失败：' + (e?.message || '网络错误')
    ElMessage.error('配额检测失败')
  } finally {
    checking.value = false
  }
}

async function handleRecord() {
  recording.value = true
  tip.value = ''
  try {
    const uid = Number(localStorage.getItem('currentUserId') || localStorage.getItem('userId') || 0)
    const tok = mockTokens.value
    const res = await recordChatUsage({
      userId: uid || undefined,
      model: model.value,
      promptTokens: Math.round(tok * 0.3),
      completionTokens: Math.round(tok * 0.7)
    })
    if (res.success !== false) {
      tipOk.value = true
      tip.value = `已记录消耗 ${formatNum(tok)} tokens`
      ElMessage.success('消耗已记录')
      await refresh()
    } else {
      tipOk.value = false
      tip.value = res.message || '记录失败（可能已超额）'
      ElMessage.error(tip.value)
      await refresh()
    }
  } catch (e: any) {
    tipOk.value = false
    tip.value = e?.response?.data?.message || e?.message || '记录失败'
    ElMessage.error(tip.value)
  } finally {
    recording.value = false
  }
}

onMounted(() => {
  refresh()
})
</script>

<style scoped>
.token-stats-page :deep(.el-card__header) {
  padding: 16px 20px;
  border-bottom: 1px solid #f1f5f9;
}
.token-stats-page :deep(.el-card__body) {
  padding: 20px;
}
.tabular-nums {
  font-variant-numeric: tabular-nums;
}
</style>
