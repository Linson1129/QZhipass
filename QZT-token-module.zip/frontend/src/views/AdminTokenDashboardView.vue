<template>
  <div class="admin-token-page min-h-screen bg-slate-100">
    <!-- 顶部栏 -->
    <header class="bg-slate-900 text-white">
      <div class="max-w-screen-2xl mx-auto px-6 py-3 flex items-center justify-between">
        <div class="flex items-center gap-4">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <el-icon :size="18" color="#fff"><Monitor /></el-icon>
            </div>
            <div>
              <span class="font-bold text-lg tracking-tight">企智通</span>
              <el-tag size="small" effect="dark" class="ml-2 !bg-white/10 !border-0 !text-blue-200">管理员后台</el-tag>
            </div>
          </div>
          <div class="text-xs text-slate-400 pl-4 border-l border-white/20 hidden sm:block">
            Token 统计与配额管理
          </div>
        </div>
        <div class="flex items-center gap-3 text-sm">
          <div class="flex items-center gap-2 px-3 py-1.5 bg-white/10 rounded-2xl">
            <el-avatar :size="24" class="bg-blue-500 text-white text-xs">管</el-avatar>
            <span class="font-medium">{{ adminName }}</span>
            <el-tag size="small" type="success" effect="dark" class="!text-[10px]">Admin</el-tag>
          </div>
          <el-button text class="!text-white" @click="refreshAll" :loading="loading">
            <el-icon><Refresh /></el-icon>
          </el-button>
        </div>
      </div>
    </header>

    <main class="max-w-screen-2xl mx-auto px-6 pt-8 pb-12 space-y-6">
      <!-- 标题 -->
      <div class="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div>
          <h1 class="text-2xl md:text-3xl font-bold tracking-tight text-slate-900">Token 使用统计看板</h1>
          <p class="text-slate-500 mt-1 text-sm">实时监控全员 Token 消耗 · 配额管理 · 立即生效</p>
        </div>
        <div class="flex items-center gap-3">
          <el-button @click="refreshAll" :loading="loading">
            <el-icon class="mr-1"><Refresh /></el-icon>
            刷新数据
          </el-button>
          <div class="text-xs px-3 py-2 bg-white border border-slate-200 rounded-xl text-slate-500 flex items-center gap-2">
            <el-icon><Clock /></el-icon>
            最后更新：{{ lastUpdated || '—' }}
          </div>
        </div>
      </div>

      <!-- KPI 卡片 -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
        <el-card shadow="hover" class="rounded-2xl border-slate-100 !overflow-visible">
          <div class="flex justify-between items-start">
            <div>
              <div class="text-sm text-slate-500">活跃用户数</div>
              <div class="text-4xl font-semibold tabular-nums tracking-tighter mt-2 text-slate-900">
                {{ kpi.activeUsers }}
              </div>
              <div class="text-emerald-600 text-sm mt-1">今日有消耗的用户</div>
            </div>
            <div class="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center">
              <el-icon :size="24"><User /></el-icon>
            </div>
          </div>
        </el-card>

        <el-card shadow="hover" class="rounded-2xl border-slate-100">
          <div class="flex justify-between items-start">
            <div>
              <div class="text-sm text-slate-500">超额用户数</div>
              <div class="text-4xl font-semibold tabular-nums tracking-tighter mt-2 text-red-600">
                {{ kpi.overQuotaUsers }}
              </div>
              <div class="text-red-500 text-sm mt-1">已达或超过限额</div>
            </div>
            <div class="w-12 h-12 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center">
              <el-icon :size="24"><WarningFilled /></el-icon>
            </div>
          </div>
        </el-card>

        <el-card shadow="hover" class="rounded-2xl border-slate-100">
          <div class="flex justify-between items-start">
            <div>
              <div class="text-sm text-slate-500">今日总消耗</div>
              <div class="flex items-baseline mt-2">
                <span class="text-4xl font-semibold tabular-nums tracking-tighter text-slate-900">
                  {{ totalConsumptionM }}
                </span>
                <span class="text-xl text-slate-400 ml-1">M</span>
              </div>
              <div class="text-slate-500 text-sm mt-1">单位：百万 tokens</div>
            </div>
            <div class="w-12 h-12 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center">
              <el-icon :size="24"><TrendCharts /></el-icon>
            </div>
          </div>
        </el-card>
      </div>

      <!-- 图表占位 -->
      <el-card shadow="never" class="rounded-2xl border-slate-100">
        <template #header>
          <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <div class="font-semibold text-slate-800 flex items-center gap-2">
                <el-icon class="text-blue-600"><Histogram /></el-icon>
                近 7 日各模型 Token 消耗趋势
              </div>
              <p class="text-sm text-slate-500 mt-0.5">按天统计 · 不同颜色区分大模型</p>
            </div>
            <div class="flex flex-wrap gap-2 text-xs">
              <el-tag type="primary" effect="plain" round>千问</el-tag>
              <el-tag type="success" effect="plain" round>DeepSeek</el-tag>
              <el-tag type="warning" effect="plain" round>Llama / 其他</el-tag>
            </div>
          </div>
        </template>
        <div class="h-64 flex items-center justify-center text-slate-400 text-sm bg-slate-50 rounded-xl">
          <div class="text-center">
            <el-icon :size="40" class="mb-2 opacity-40"><DataLine /></el-icon>
            <p>图表数据来自 dashboard.chartData</p>
            <p class="text-xs mt-1">后端返回后可接入 ECharts / Chart.js</p>
          </div>
        </div>
      </el-card>

      <!-- 员工表 + 配额设置 -->
      <div class="grid grid-cols-1 xl:grid-cols-12 gap-6">
        <!-- 员工明细表 -->
        <el-card shadow="never" class="xl:col-span-8 rounded-2xl border-slate-100 !p-0 overflow-hidden">
          <template #header>
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <span class="font-semibold text-slate-800">员工 Token 使用明细（今日）</span>
              <div class="flex items-center gap-2">
                <el-select v-model="deptFilter" placeholder="全部部门" clearable size="default" style="width: 140px" @change="applyFilter">
                  <el-option label="全部部门" value="" />
                  <el-option v-for="d in departments" :key="d" :label="d" :value="d" />
                </el-select>
                <el-input
                  v-model="keyword"
                  placeholder="搜索姓名或 ID..."
                  clearable
                  style="width: 180px"
                  @input="applyFilter"
                >
                  <template #prefix>
                    <el-icon><Search /></el-icon>
                  </template>
                </el-input>
              </div>
            </div>
          </template>

          <el-table
            :data="filteredUsers"
            stripe
            height="420"
            v-loading="loading"
            class="w-full"
          >
            <el-table-column label="员工" min-width="160">
              <template #default="{ row }">
                <div class="flex items-center gap-3">
                  <el-avatar :size="28" class="bg-blue-100 text-blue-700 text-xs font-semibold">
                    {{ (row.name || '?').charAt(0) }}
                  </el-avatar>
                  <div>
                    <div class="font-medium text-slate-800">{{ row.name }}</div>
                    <div class="text-xs text-slate-400 font-mono">ID: {{ row.id }}</div>
                  </div>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="department" label="部门" width="110">
              <template #default="{ row }">
                <el-tag size="small" effect="plain" type="info">{{ row.department || '—' }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column label="今日用量" width="120" align="right">
              <template #default="{ row }">
                <span class="font-mono font-semibold">{{ formatNum(row.totalTokens) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="限额" width="110" align="right">
              <template #default="{ row }">
                <span class="font-mono text-slate-500">{{ formatNum(row.quota) }}</span>
              </template>
            </el-table-column>
            <el-table-column label="使用率" width="100" align="center">
              <template #default="{ row }">
                <div class="flex flex-col items-center gap-1">
                  <el-progress
                    :percentage="rowPercent(row)"
                    :stroke-width="6"
                    :show-text="false"
                    :color="rowPercent(row) > 90 ? '#ef4444' : rowPercent(row) > 70 ? '#f59e0b' : '#10b981'"
                    class="w-14"
                  />
                  <span class="text-xs font-medium">{{ rowPercent(row) }}%</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column label="状态" width="100" align="center">
              <template #default="{ row }">
                <el-tag
                  :type="row.overQuota ? 'danger' : rowPercent(row) > 85 ? 'warning' : 'success'"
                  size="small"
                  effect="light"
                  round
                >
                  {{ row.overQuota ? '已超额' : rowPercent(row) > 85 ? '即将超' : '正常' }}
                </el-tag>
              </template>
            </el-table-column>
          </el-table>

          <div class="px-5 py-3 bg-slate-50 text-xs text-slate-500 flex justify-between items-center border-t border-slate-100">
            <div>共 <strong>{{ filteredUsers.length }}</strong> 人 · 每日 00:00 自动清零</div>
          </div>
        </el-card>

        <!-- 统一配额设置 -->
        <el-card shadow="never" class="xl:col-span-4 rounded-2xl border-slate-100 flex flex-col">
          <template #header>
            <div class="font-semibold text-slate-800 flex items-center gap-2">
              <el-icon class="text-blue-600"><Setting /></el-icon>
              统一配额设置
            </div>
          </template>

          <div class="mb-6">
            <div class="text-xs text-slate-500 mb-1">当前全局默认限额</div>
            <div class="flex items-baseline">
              <span class="font-mono text-5xl font-semibold tabular-nums tracking-tighter text-slate-900">
                {{ formatNum(globalLimit) }}
              </span>
              <span class="text-slate-400 ml-2 text-sm">tokens/日</span>
            </div>
          </div>

          <div class="mt-auto space-y-3">
            <div>
              <label class="text-xs font-medium text-slate-500 block mb-2">设置新的统一限额（立即生效）</label>
              <el-input-number
                v-model="newLimit"
                :min="1000"
                :step="5000"
                controls-position="right"
                class="w-full !text-lg"
                size="large"
              />
            </div>
            <el-button
              type="primary"
              size="large"
              class="w-full !rounded-xl"
              :loading="saving"
              @click="applyQuota"
            >
              保存并应用
            </el-button>
            <p class="text-[11px] text-amber-600 flex items-center gap-1.5">
              <el-icon><Lightning /></el-icon>
              调用 PUT /api/v1/admin/token/quota 后立即生效
            </p>
          </div>
        </el-card>
      </div>

      <!-- 部门汇总（可选） -->
      <el-card v-if="deptRows.length" shadow="never" class="rounded-2xl border-slate-100">
        <template #header>
          <span class="font-semibold text-slate-800">按部门统计 · 当日 Token 使用情况</span>
        </template>
        <el-table :data="deptRows" stripe>
          <el-table-column prop="department" label="部门" />
          <el-table-column prop="userCount" label="员工数" width="100" align="center" />
          <el-table-column label="当日总 Token" align="right">
            <template #default="{ row }">
              <span class="font-mono">{{ formatNum(row.totalTokens) }}</span>
            </template>
          </el-table-column>
          <el-table-column label="超额人数" width="110" align="center">
            <template #default="{ row }">
              <span :class="row.overQuotaCount > 0 ? 'text-red-600 font-semibold' : ''">
                {{ row.overQuotaCount }}
              </span>
            </template>
          </el-table-column>
        </el-table>
      </el-card>
    </main>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import {
  Monitor, Refresh, Clock, User, WarningFilled, TrendCharts,
  Histogram, DataLine, Search, Setting, Lightning
} from '@element-plus/icons-vue'
import {
  getAdminTokenDashboard,
  getAdminTokenUsage,
  updateGlobalQuota
} from '@/api/token'

interface UserRow {
  id: number | string
  name: string
  department: string
  totalTokens: number
  quota: number
  overQuota: boolean
}

interface DeptRow {
  department: string
  userCount: number
  totalTokens: number
  overQuotaCount: number
}

const loading = ref(false)
const saving = ref(false)
const lastUpdated = ref('')
const adminName = computed(() => localStorage.getItem('currentUserName') || '管理员')

const kpi = ref({
  activeUsers: 0,
  overQuotaUsers: 0,
  todayTotalConsumption: 0
})
const globalLimit = ref(100000)
const newLimit = ref(100000)
const allUsers = ref<UserRow[]>([])
const filteredUsers = ref<UserRow[]>([])
const deptRows = ref<DeptRow[]>([])
const deptFilter = ref('')
const keyword = ref('')

const departments = computed(() => {
  const set = new Set(allUsers.value.map(u => u.department).filter(Boolean))
  return Array.from(set).sort()
})

const totalConsumptionM = computed(() =>
  ((kpi.value.todayTotalConsumption || 0) / 1_000_000).toFixed(1)
)

function formatNum(n: number) {
  return (n ?? 0).toLocaleString()
}

function rowPercent(row: UserRow) {
  if (!row.quota) return 0
  return Math.min(100, Math.round((row.totalTokens / row.quota) * 100))
}

function applyFilter() {
  let list = allUsers.value
  if (deptFilter.value) {
    list = list.filter(u => u.department === deptFilter.value)
  }
  if (keyword.value.trim()) {
    const kw = keyword.value.trim().toLowerCase()
    list = list.filter(
      u =>
        (u.name || '').toLowerCase().includes(kw) ||
        String(u.id).toLowerCase().includes(kw)
    )
  }
  filteredUsers.value = list
}

async function loadDashboard() {
  try {
    const d = await getAdminTokenDashboard()
    kpi.value = {
      activeUsers: d.activeUsers ?? 0,
      overQuotaUsers: d.overQuotaUsers ?? 0,
      todayTotalConsumption: d.todayTotalConsumption ?? 0
    }
    if (d.globalLimit || d.daily_token_limit) {
      globalLimit.value = d.globalLimit || d.daily_token_limit
      newLimit.value = globalLimit.value
    }
  } catch (e: any) {
    console.warn('dashboard load failed', e)
  }
}

async function loadUsage() {
  try {
    const d = await getAdminTokenUsage()
    const rows = d.userUsageRows || d.users || []
    allUsers.value = rows.map((u: any) => ({
      id: u.userId ?? u.id,
      name: u.name || '—',
      department: u.department || '—',
      totalTokens: u.totalTokens ?? 0,
      quota: u.quota ?? globalLimit.value,
      overQuota:
        u.overQuota !== undefined
          ? u.overQuota
          : (u.totalTokens ?? 0) >= (u.quota ?? globalLimit.value)
    }))
    deptRows.value = d.departmentRows || d.departments || []
    applyFilter()
  } catch (e: any) {
    console.warn('usage load failed', e)
    ElMessage.error(e?.response?.data?.message || '获取员工用量失败')
  }
}

async function refreshAll() {
  loading.value = true
  try {
    await Promise.all([loadDashboard(), loadUsage()])
    lastUpdated.value = new Date().toLocaleString()
  } finally {
    loading.value = false
  }
}

async function applyQuota() {
  if (!newLimit.value || newLimit.value < 1000) {
    ElMessage.warning('请输入有效限额（≥ 1000）')
    return
  }
  saving.value = true
  try {
    const res = await updateGlobalQuota(newLimit.value)
    if (res.success !== false) {
      globalLimit.value = newLimit.value
      // 本地同步更新员工限额展示
      allUsers.value.forEach(u => {
        u.quota = newLimit.value
        u.overQuota = u.totalTokens >= newLimit.value
      })
      applyFilter()
      ElMessage.success(`全局配额已更新为 ${formatNum(newLimit.value)}，立即生效`)
      await loadDashboard()
    } else {
      ElMessage.error(res.message || '保存失败')
    }
  } catch (e: any) {
    ElMessage.error(e?.response?.data?.message || e?.message || '保存失败')
  } finally {
    saving.value = false
  }
}

onMounted(() => {
  refreshAll()
})
</script>

<style scoped>
.admin-token-page :deep(.el-card__header) {
  padding: 16px 20px;
  border-bottom: 1px solid #f1f5f9;
}
.admin-token-page :deep(.el-card__body) {
  padding: 20px;
}
.tabular-nums {
  font-variant-numeric: tabular-nums;
}
</style>
